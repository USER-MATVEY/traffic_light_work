package com.example.transport_programm

class Character (
    val id: Long,
    val name: String,
    val isCustom: Boolean
)